# VRBox Neural Tracking — Preview 0.2.1

Website de hand tracking em tempo real, preparado para empacotamento Android com Capacitor. Esta versão amplia o protótipo inicial e reúne captura, inferência em Worker, visualização 2D/3D, compensação temporal, gestos, calibração visual, benchmarks e integração via WebSocket.

> **Honestidade técnica:** isto não é o FMM da Meta, não usa código ou pesos proprietários da Meta e não é equivalente ao Quest 3S. O perfil `FMM-inspired` solicita alta frequência, adapta o ritmo de inferência e tenta aplicar exposição curta somente quando a API do navegador anuncia suporte. A arquitetura ainda não controla diretamente a sessão Camera2 do WebView.

## O que foi acrescentado em 0.2.1

### Captura e runtime
- Câmera via `getUserMedia`, seletor de câmera, solicitação de 1280×720 e até 60 FPS (o dispositivo decide o que realmente entrega).
- Perfil `Adaptive Neural Runtime`: aumenta a taxa de inferência solicitada em movimento rápido e reduz quando a inferência fica pesada.
- Perfil `FMM-inspired · Fast Motion`: solicita 60 FPS à trilha da câmera e prioriza captura/inferência responsivas.
- Tentativa opcional de modo manual de exposição quando `getCapabilities()` expõe os controles necessários. A API pode ocultar ou rejeitar esses controles.
- Fila de inferência limitada a um frame em voo; frames antigos são descartados em vez de acumular atraso.
- Modelo executado em Web Worker, com tentativa de delegate GPU e fallback CPU.

### Visão, blur e continuidade
- MediaPipe Hand Landmarker: até duas mãos, 21 landmarks por mão e world landmarks fornecidos pelo modelo.
- `TemporalPoseEngine`: filtro adaptativo inspirado em One Euro, estima velocidade e faz extrapolação curta durante perdas momentâneas.
- `BlurAnalyzer`: variância do Laplaciano para uma estimativa de nitidez; movimento rápido + baixa nitidez gera um indicador heurístico de risco de blur.
- Quando o risco heurístico aumenta, o sistema pode reduzir temporariamente os thresholds de detecção/presença/tracking para favorecer recall.
- Indicador experimental de risco de rolling shutter, sem correção geométrica real.

### Pose 3D e visualização
- Visualizações 2D `Skeleton`, `Segments` e `Combined`.
- Visualizações 3D `Skeleton`, `Segments` e `Hand volume` com bones, articulações, cilindros e uma superfície simplificada da palma.
- Estimativa de pose baseada nos world landmarks do Hand Landmarker.
- Perfil de escala visual da palma salvo localmente.

### Interação e integração
- Classificador heurístico de `Pinch`, `Open`, `Peace`, `Point`, `Thumbs up`, `Fist` e `Grab`.
- `window.VRBoxNeuralTracking` com `getState()`, `subscribe(callback)`, `connectBridge(url)`, `disconnectBridge()` e `onController(callback)`.
- Eventos DOM `vrbox:frame` e `vrbox:controller`.
- Bridge WebSocket: envia landmarks, gestos e métricas; recebe mensagens `vrbox.controller` ou `vrbox.input` de um integrador externo.
- Gravação de amostras de pose em JSON.
- Benchmark CSV com FPS, inferência, round trip, mãos, confiança, velocidade, nitidez e extrapolações.

### APK / Android
- Capacitor configurado para gerar o projeto Android localmente.
- Plugin Kotlin opcional `android-native-plugin/Camera2DiagnosticsPlugin.kt` para consultar características Camera2 (nível de hardware, faixa de exposição, sensibilidade e intervalos FPS anunciados).
- O plugin Camera2 é somente leitura. Consultar capacidades não muda a exposição da câmera usada pelo WebView.

## O que FMM realmente significa aqui

A Meta documenta o Fast Motion Mode como um modo específico do Horizon OS para dispositivos Quest compatíveis. A documentação atual descreve rastreamento de alta frequência por volta de 60 Hz e alerta para maior jitter e piora com pouca luz por causa da exposição curta. O modo nativo é acionado pelas APIs do Meta XR/OVR, que não existem no navegador de um Galaxy A36.

Neste projeto, `FMM-inspired` é uma **estratégia própria inspirada nos objetivos do FMM**, não a implementação Meta. Ela pode solicitar maior frequência de frames e tentar exposição manual, mas o navegador e o sensor podem ignorar ou limitar os pedidos. A taxa real aparece no diagnóstico.

## Inventário completo da proposta

| Módulo | Estado nesta versão |
|---|---|
| Perfil FMM-inspired | Implementado como solicitação de captura e pacing; não é o FMM Meta |
| Motion blur | Proxy de nitidez + resposta temporal; rede neural de deblur ainda não treinada |
| 3D | Landmarks espaciais + render articulado simplificado; MANO e profundidade métrica ainda não |
| Baixa latência | Worker, fila de um frame, descarte de quadros antigos e métricas internas |
| WMM / corpo | Extrapolação curta dentro da cena; body tracking verdadeiro não disponível |
| Oclusão | Ponte temporal configurável para perdas breves |
| Jitter | Filtro adaptativo por coordenada/articulação |
| Rolling shutter | Indicador heurístico; sem correção geométrica |
| Adaptive Neural Runtime | Perfil adaptativo de taxa-alvo usando custo de inferência e movimento |
| Calibração pessoal | Escala visual da palma salva localmente |
| Gestos | Classificação geométrica heurística de gestos básicos |
| Multimodal / controles | WebSocket Bridge para dados enviados por outro programa |
| Câmeras múltiplas | Enumeração; ainda sem sincronização, calibração estéreo ou fusão |
| Camera2 | Plugin Kotlin opcional de inventário somente leitura |
| Developer tools | API JS, eventos, benchmark CSV e gravação de poses JSON |
| Hand segmentation | Não implementada; exige modelo próprio ou integração de segmentador compatível |
| Neural motion deblurring | Não implementado; exige dataset, treinamento e validação em hardware-alvo |

## Limites que continuam abertos

1. **Motion blur neural:** ainda não existe neste pacote uma rede própria treinada para desfazer borrão ou recuperar detalhes ausentes. O atual assistente calcula nitidez, percebe combinação aproximada de movimento/blur e usa compensação temporal curta.
2. **Reconstrução 3D:** world landmarks são estimativas espaciais do modelo, não medidas métricas verificadas. O volume 3D é uma visualização articulada simplificada; não é uma malha MANO ajustada nem uma reconstrução ground-truth.
3. **WMM / tracking fora do campo de visão:** a Meta combina hand tracking com Inside-Out Body Tracking. O website não recebe esses dados. O nosso recurso mantém uma pose extrapolada por uma janela curta enquanto a mão some dentro/ao redor da imagem; não reconstrói braço ou mão fora da câmera.
4. **Multimodal / controles:** o navegador não tem acesso universal aos controladores VR. O WebSocket Bridge permite que outra aplicação envie os dados se ela os disponibilizar.
5. **Fusão de câmeras:** o site lista as câmeras disponíveis, mas não faz calibração estéreo, sincronização nem fusão simultânea nesta versão.
6. **Exposição e Camera2:** as APIs de captura web expõem capacidades diferentes conforme dispositivo/browser. O plugin nativo consulta características Camera2, mas não controla a sessão de câmera do WebView.
7. **Latência:** `Inference` mede a chamada do modelo. `Pipeline Round Trip` mede o tempo interno desde antes de criar/transferir o bitmap até receber o resultado. Nenhum desses números é motion-to-photon. Para isso, precisamos de medição externa de alta velocidade ou instrumentação física.
8. **Temperatura:** Android/WebView não oferece uma API web genérica e confiável para temperatura. O app mostra cores de diagnóstico, núcleos e memória reportada quando disponíveis, mas não inventa temperatura.

## Requisitos

- Node.js 22.12+.
- Navegador atualizado com câmera, módulos ES, Web Worker e WebGL.
- HTTPS para usar a câmera em um website publicado; `localhost` é aceito em desenvolvimento.
- Internet na primeira inicialização para obter os arquivos WASM e o modelo MediaPipe.
- Para gerar APK: Android Studio, JDK e Android SDK compatíveis com Capacitor 8.

## Rodar no Windows

1. Instale Node.js 22.12+.
2. Extraia o ZIP.
3. Execute `start-windows.bat`, ou rode:

```bash
npm install
npm run dev
```

4. Acesse `http://localhost:5173`.

Para usar no Galaxy A36, publique em HTTPS e abra no Chrome. O site não ganha permissões de câmera quando aberto por HTTP comum via IP local.

## Testes e build

```bash
npm test
npm run build
npm run preview
```

O teste unitário usa o runner nativo do Node para os módulos temporais, gestos e benchmark. O build completo precisa das dependências npm instaladas.

## Gerar APK pelo Capacitor

Depois de instalar dependências e Android Studio:

```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```

Ou use `build-android-windows.bat`. No Android Studio, gere o APK em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Para adicionar o diagnóstico nativo Camera2, siga `android-native-plugin/README.md`. O plugin é opcional e só reporta capacidades; não altera o fluxo de captura web.

## Exemplo de Developer API

```js
// Consulte o estado atual
const state = window.VRBoxNeuralTracking.getState();

// Receba atualizações durante o rastreamento
const unsubscribe = window.VRBoxNeuralTracking.subscribe((frame) => {
  console.log(frame.hands, frame.gestures, frame.motion);
});

// Encerre quando não precisar mais
unsubscribe();
```

O WebSocket Bridge transmite mensagens JSON com o tipo `vrbox.handtracking.frame`. Mensagens externas de controlador podem usar `{"type":"vrbox.controller","data":{...}}`.

## Privacidade

O código deste projeto não envia os frames da câmera para um servidor próprio. Os frames são processados localmente pelo MediaPipe no dispositivo. A biblioteca MediaPipe pode enviar métricas de uso/diagnóstico conforme sua documentação de privacidade. A gravação de poses e benchmarks só é criada quando o usuário aciona os controles de gravação/exportação. O perfil de calibração fica no `localStorage` do dispositivo.

## Referências técnicas

- Meta — Fast Motion Mode: <https://developers.meta.com/vr/documentation/unity/fast-motion-mode/>
- Meta — Hands Technology: <https://developers.meta.com/vr/design/hands-technology/>
- Meta — Wide Motion Mode: <https://developers.meta.com/vr/documentation/unity/unity-wide-motion-mode/>
- Meta — Hands 2.2: <https://developers.meta.com/vr/blog/hand-tracking-22-response-time-meta-quest-developers/>
- Google — MediaPipe Hand Landmarker: <https://developers.google.com/edge/mediapipe/solutions/vision/hand_landmarker?tab=Web>
- MDN — MediaStreamTrack.applyConstraints: <https://developer.mozilla.org/en-US/docs/Web/API/MediaStreamTrack/applyConstraints>
- Capacitor: <https://capacitorjs.com/docs>
- Three.js: <https://threejs.org/docs/>
