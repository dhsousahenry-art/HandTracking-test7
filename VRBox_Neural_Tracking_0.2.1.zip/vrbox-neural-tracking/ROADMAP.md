# VRBox Neural Tracking — status técnico

## Preview 0.2.1 — incluído no pacote atual

- [x] Website responsivo e base Capacitor.
- [x] Câmera web, seletor e diagnóstico do stream.
- [x] Hand Landmarker em Worker com fallback GPU/CPU.
- [x] Skeleton, Segments e Combined em 2D.
- [x] Pose espacial baseada nos world landmarks e render 3D articulado simplificado.
- [x] Perfil FMM-inspired: solicitação de até 60 FPS, pacing adaptativo e tentativa de exposição curta quando a API permitir.
- [x] Descarte de frames antigos e limite de uma inferência em voo.
- [x] Filtro temporal adaptativo, estimativa de velocidade e extrapolação curta para perdas rápidas.
- [x] Proxy de nitidez / risco heurístico de motion blur.
- [x] Threshold de inferência adaptativo diante de blur/alta velocidade.
- [x] Gestos heurísticos e indicadores de pinch.
- [x] Calibração de escala visual da palma.
- [x] Benchmark CSV, gravação JSON de poses e Developer API.
- [x] WebSocket Bridge para integração externa / entrada de controladores disponibilizada por outro app.
- [x] Testes unitários dos módulos puros.
- [x] Plugin Kotlin opcional para inventário de capacidades Camera2.
- [x] Perfil Adaptive Neural Runtime com cadência-alvo baseada em inferência e movimento.
- [x] Filtro temporal adaptativo e predição curta no espaço de imagem e world landmarks.
- [x] Indicador heurístico de risco de rolling shutter.

## Pesquisa / integração ainda necessária

- [ ] Rede própria de hand segmentation e motion-deblurring treinada com imagens reais/sintéticas.
- [ ] Fusão neural de múltiplos quadros para pose sob blur intenso.
- [ ] Ajuste de modelo anatômico MANO e validação métrica com ground truth.
- [ ] Captura nativa Camera2 de alta velocidade integrada diretamente à inferência.
- [ ] Correção geométrica real de rolling shutter.
- [ ] Modelo neural de previsão de pose temporal e estimação de incerteza por articulação.
- [ ] Integração com sensores corporais e controladores VR reais.

## Não declarar como concluído

- [ ] FMM Meta original / acesso a OVRPlugin.
- [ ] WMM real com Inside-Out Body Tracking.
- [ ] Rede neural própria para motion deblurring.
- [ ] Ajuste MANO / reconstrução 3D métrica com ground truth.
- [ ] Câmeras sincronizadas, calibração estéreo e fusão multi-view.
- [ ] Captura Android nativa Camera2 controlando a mesma sessão entregue ao inferenciador.
- [ ] Integração nativa universal com controladores VR.
- [ ] Medição física de motion-to-photon.

## Próximas validações recomendadas

1. Instalar dependências e executar os testes.
2. Abrir em HTTPS no Galaxy A36 e gravar um benchmark de 30–60 segundos.
3. Comparar perfis Balanced e FMM-inspired sob a mesma iluminação.
4. Repetir com movimento lento/rápido, fundo simples/complexo e oclusões curtas.
5. Registrar FPS real do stream, inferência p50/p95, pipeline p50/p95, nitidez e perdas.
6. Decidir se é necessário substituir a captura WebView por um pipeline Android Camera2 nativo.
7. Só então investir em dataset e treinamento de modelo próprio de blur-aware pose.
