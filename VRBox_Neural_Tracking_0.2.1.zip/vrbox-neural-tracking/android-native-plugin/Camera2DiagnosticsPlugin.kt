package com.vrbox.neuraltracking

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.util.Range
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin

/**
 * Read-only Camera2 inventory for the VRBox Neural Tracking Capacitor shell.
 * It does not open the camera or modify an active WebView camera session.
 */
@CapacitorPlugin(name = "Camera2Diagnostics")
class Camera2DiagnosticsPlugin : Plugin() {
    @PluginMethod
    fun getCapabilities(call: PluginCall) {
        try {
            val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val cameras = JSArray()
            for (cameraId in manager.cameraIdList) {
                val characteristics = manager.getCameraCharacteristics(cameraId)
                val fpsRanges = characteristics.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
                val exposureRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)
                val sensitivityRange = characteristics.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)
                val facing = when (characteristics.get(CameraCharacteristics.LENS_FACING)) {
                    CameraCharacteristics.LENS_FACING_FRONT -> "front"
                    CameraCharacteristics.LENS_FACING_BACK -> "back"
                    CameraCharacteristics.LENS_FACING_EXTERNAL -> "external"
                    else -> "unknown"
                }
                val level = when (characteristics.get(CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL)) {
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEGACY -> "LEGACY"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LIMITED -> "LIMITED"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_FULL -> "FULL"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_LEVEL_3 -> "LEVEL_3"
                    CameraCharacteristics.INFO_SUPPORTED_HARDWARE_LEVEL_EXTERNAL -> "EXTERNAL"
                    else -> "UNKNOWN"
                }
                val camera = JSObject()
                camera.put("id", cameraId)
                camera.put("facing", facing)
                camera.put("hardwareLevel", level)
                camera.put("flashAvailable", characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) ?: false)
                camera.put("manualSensor", characteristics.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) ?: false)
                camera.put("exposureTimeNs", rangeToJson(exposureRange?.lower, exposureRange?.upper))
                camera.put("sensitivityIso", rangeToJson(sensitivityRange?.lower, sensitivityRange?.upper))
                camera.put("targetFpsRanges", rangesToJson(fpsRanges))
                cameras.put(camera)
            }
            val result = JSObject()
            result.put("platform", "android-camera2")
            result.put("readOnly", true)
            result.put("cameras", cameras)
            call.resolve(result)
        } catch (error: Exception) {
            call.reject("Camera2 diagnostics failed: ${error.message}", error)
        }
    }

    private fun rangeToJson(minimum: Long?, maximum: Long?): JSObject? {
        if (minimum == null || maximum == null) return null
        val result = JSObject()
        result.put("min", minimum)
        result.put("max", maximum)
        return result
    }

    private fun rangeToJson(minimum: Int?, maximum: Int?): JSObject? {
        if (minimum == null || maximum == null) return null
        val result = JSObject()
        result.put("min", minimum)
        result.put("max", maximum)
        return result
    }

    private fun rangesToJson(ranges: Array<Range<Int>>?): JSArray {
        val array = JSArray()
        ranges?.forEach { range ->
            val item = JSObject()
            item.put("min", range.lower)
            item.put("max", range.upper)
            array.put(item)
        }
        return array
    }
}
