# Android Camera2 diagnostics plugin (optional)

Este plugin opcional é usado pela versão Capacitor para consultar as características do sensor Android sem abrir uma segunda sessão de câmera. Ele fornece IDs, posição da lente, nível de hardware, intervalos de FPS anunciados e faixas de exposição/sensibilidade quando disponíveis.

## Integração depois de `npm run android:add`

1. Copie `Camera2DiagnosticsPlugin.kt` para:
   `android/app/src/main/java/com/vrbox/neuraltracking/Camera2DiagnosticsPlugin.kt`
2. Confira se o `package` do arquivo corresponde ao pacote Android configurado em `capacitor.config.ts` (`com.vrbox.neuraltracking`).
3. Abra `android/app/src/main/java/com/vrbox/neuraltracking/MainActivity.java` ou `.kt` e registre o plugin **antes** de `super.onCreate`.

Exemplo Java:

```java
package com.vrbox.neuraltracking;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(Camera2DiagnosticsPlugin.class);
    super.onCreate(savedInstanceState);
  }
}
```

Se o template do Capacitor criar `MainActivity.kt`, use a mesma chamada Kotlin:

```kotlin
registerPlugin(Camera2DiagnosticsPlugin::class.java)
super.onCreate(savedInstanceState)
```

Depois rode `npx cap sync android` e compile novamente.

## Limite importante

O plugin é **somente leitura**. Ele não controla a exposição da câmera que o WebView está usando. Para aplicar tempos de exposição manual em tempo real, seria necessário substituir a captura WebView por uma sessão Camera2 nativa e encaminhar os frames ao motor de inferência. Consultar `SENSOR_INFO_EXPOSURE_TIME_RANGE` não significa que o stream esteja usando uma exposição curta.

No `AndroidManifest.xml`, adicione dentro de `<manifest>` (fora de `<application>`), caso o template ainda não tenha incluído:

```xml
<uses-permission android:name="android.permission.CAMERA" />
<uses-feature android:name="android.hardware.camera.any" android:required="false" />
```

O plugin só lê características do hardware. A permissão de câmera continua sendo solicitada quando o usuário inicia a sessão de vídeo.
