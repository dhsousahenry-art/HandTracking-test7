@echo off
setlocal
cd /d "%~dp0"
if not exist node_modules (
  echo Instalando dependencias...
  call npm install || goto :error
)
if not exist android (
  echo Criando projeto Android do Capacitor...
  call npx cap add android || goto :error
)
echo Gerando build web...
call npm run build || goto :error
echo Sincronizando projeto Android...
call npx cap sync android || goto :error
echo Abrindo Android Studio...
call npx cap open android
exit /b 0
:error
echo O processo falhou. Confira as mensagens acima.
pause
exit /b 1
