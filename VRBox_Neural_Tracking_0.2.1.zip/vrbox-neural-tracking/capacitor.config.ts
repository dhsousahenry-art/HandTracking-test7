import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.vrbox.neuraltracking',
  appName: 'VRBox Neural Tracking',
  webDir: 'dist',
  android: {
    allowMixedContent: false,
  },
};

export default config;
