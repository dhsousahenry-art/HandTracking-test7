function csvCell(value) {
  const text = value === null || value === undefined ? '' : String(value);
  return /[",\n]/.test(text) ? `"${text.replaceAll('"', '""')}"` : text;
}

export class BenchmarkRecorder {
  constructor() { this.active = false; this.startedAt = 0; this.samples = []; }
  start() { this.samples = []; this.startedAt = performance.now(); this.active = true; }
  add(sample) {
    if (!this.active) return;
    this.samples.push({ elapsedMs: performance.now() - this.startedAt, ...sample });
  }
  stop() { this.active = false; return this.summary(); }
  summary() {
    const values = (key) => this.samples.map((row) => Number(row[key])).filter(Number.isFinite).sort((a, b) => a - b);
    const percentile = (arr, p) => arr.length ? arr[Math.min(arr.length - 1, Math.floor((arr.length - 1) * p))] : null;
    const inference = values('inferenceMs');
    const pipeline = values('pipelineMs');
    const fps = values('fps');
    return {
      samples: this.samples.length,
      durationMs: this.samples.at(-1)?.elapsedMs ?? 0,
      inferenceMedian: percentile(inference, 0.5),
      inferenceP95: percentile(inference, 0.95),
      pipelineMedian: percentile(pipeline, 0.5),
      pipelineP95: percentile(pipeline, 0.95),
      fpsMedian: percentile(fps, 0.5),
    };
  }
  toCSV() {
    const columns = ['elapsedMs', 'fps', 'inferenceMs', 'pipelineMs', 'hands', 'confidence', 'motionSpeed', 'sharpness', 'blurRisk', 'predictedHands'];
    return [columns.join(','), ...this.samples.map((row) => columns.map((key) => csvCell(row[key])).join(','))].join('\n');
  }
  toJSON() { return JSON.stringify({ schema: 'vrbox-benchmark-v1', startedAt: new Date(Date.now() - (performance.now() - this.startedAt)).toISOString(), summary: this.summary(), samples: this.samples }, null, 2); }
}
