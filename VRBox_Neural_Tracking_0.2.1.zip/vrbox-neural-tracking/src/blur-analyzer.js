const clamp = (value, min, max) => Math.max(min, Math.min(max, value));

/* Laplacian variance is a rough image-sharpness proxy, not a definitive motion-blur detector. */
export class BlurAnalyzer {
  constructor(width = 144, height = 96) {
    this.canvas = document.createElement('canvas');
    this.canvas.width = width;
    this.canvas.height = height;
    this.context = this.canvas.getContext('2d', { willReadFrequently: true });
    this.lastAt = 0;
    this.lastResult = { laplacianVariance: null, sharpness: null, lowSharpness: false };
  }

  analyze(video, now = performance.now(), force = false) {
    if (!video || video.readyState < 2 || !this.context || (!force && now - this.lastAt < 450)) return this.lastResult;
    this.lastAt = now;
    const { width, height } = this.canvas;
    try {
      this.context.drawImage(video, 0, 0, width, height);
      const rgba = this.context.getImageData(0, 0, width, height).data;
      const gray = new Float32Array(width * height);
      for (let i = 0, p = 0; i < rgba.length; i += 4, p += 1) gray[p] = rgba[i] * 0.299 + rgba[i + 1] * 0.587 + rgba[i + 2] * 0.114;
      let sum = 0; let sumSq = 0; let count = 0;
      for (let y = 1; y < height - 1; y += 1) {
        for (let x = 1; x < width - 1; x += 1) {
          const i = y * width + x;
          const lap = gray[i - width] + gray[i + width] + gray[i - 1] + gray[i + 1] - 4 * gray[i];
          sum += lap; sumSq += lap * lap; count += 1;
        }
      }
      const mean = sum / Math.max(1, count);
      const variance = Math.max(0, sumSq / Math.max(1, count) - mean * mean);
      const sharpness = clamp((variance / 260) * 100, 0, 100);
      this.lastResult = { laplacianVariance: variance, sharpness, lowSharpness: sharpness < 22 };
    } catch (error) {
      this.lastResult = { ...this.lastResult, error: error?.message || String(error) };
    }
    return this.lastResult;
  }
}
