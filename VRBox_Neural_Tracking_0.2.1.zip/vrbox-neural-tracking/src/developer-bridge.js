export class DeveloperBridge extends EventTarget {
  constructor() { super(); this.socket = null; this.url = ''; this.status = 'disconnected'; }
  connect(url) {
    this.disconnect();
    const parsed = new URL(url);
    if (!['ws:', 'wss:'].includes(parsed.protocol)) throw new Error('Use ws:// ou wss://.');
    if (location.protocol === 'https:' && parsed.protocol === 'ws:' && !['localhost', '127.0.0.1'].includes(parsed.hostname)) {
      throw new Error('Em páginas HTTPS, use wss:// para destinos remotos.');
    }
    this.url = parsed.toString();
    this.status = 'connecting';
    this.socket = new WebSocket(this.url);
    this.socket.addEventListener('open', () => { this.status = 'connected'; this.dispatchEvent(new CustomEvent('status', { detail: this.status })); });
    this.socket.addEventListener('close', () => { this.status = 'disconnected'; this.dispatchEvent(new CustomEvent('status', { detail: this.status })); });
    this.socket.addEventListener('error', () => { this.status = 'error'; this.dispatchEvent(new CustomEvent('status', { detail: this.status })); });
    this.socket.addEventListener('message', (event) => {
      try {
        const data = JSON.parse(event.data);
        this.dispatchEvent(new CustomEvent('message', { detail: data }));
      } catch { this.dispatchEvent(new CustomEvent('message', { detail: { raw: String(event.data) } })); }
    });
    this.dispatchEvent(new CustomEvent('status', { detail: this.status }));
  }
  send(payload) {
    if (this.socket?.readyState !== WebSocket.OPEN) return false;
    this.socket.send(JSON.stringify(payload));
    return true;
  }
  disconnect() {
    if (this.socket) { this.socket.onopen = this.socket.onclose = this.socket.onerror = this.socket.onmessage = null; this.socket.close(); }
    this.socket = null;
    this.status = 'disconnected';
  }
}
