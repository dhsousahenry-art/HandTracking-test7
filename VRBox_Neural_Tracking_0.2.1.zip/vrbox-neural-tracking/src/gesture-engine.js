const distance2D = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);

function angleAt(a, b, c) {
  const ab = { x: a.x - b.x, y: a.y - b.y };
  const cb = { x: c.x - b.x, y: c.y - b.y };
  const denominator = Math.hypot(ab.x, ab.y) * Math.hypot(cb.x, cb.y);
  if (!denominator) return 0;
  const cosine = Math.max(-1, Math.min(1, (ab.x * cb.x + ab.y * cb.y) / denominator));
  return Math.acos(cosine) * 180 / Math.PI;
}

function fingerExtended(points, mcp, pip, dip, tip) {
  const pipAngle = angleAt(points[mcp], points[pip], points[dip]);
  const dipAngle = angleAt(points[pip], points[dip], points[tip]);
  return pipAngle > 145 && dipAngle > 145;
}

export function classifyGesture(landmarks) {
  if (!Array.isArray(landmarks) || landmarks.length < 21) return { name: '—', key: 'none', pinch: 0, extended: [] };
  const p = landmarks;
  const palmWidth = Math.max(0.025, distance2D(p[5], p[17]));
  const pinchRatio = distance2D(p[4], p[8]) / palmWidth;
  const pinch = Math.max(0, Math.min(1, 1 - pinchRatio / 0.62));
  const thumbOut = distance2D(p[4], p[5]) > distance2D(p[3], p[5]) * 1.12;
  const extended = [
    thumbOut,
    fingerExtended(p, 5, 6, 7, 8),
    fingerExtended(p, 9, 10, 11, 12),
    fingerExtended(p, 13, 14, 15, 16),
    fingerExtended(p, 17, 18, 19, 20),
  ];
  const count = extended.filter(Boolean).length;
  if (pinchRatio < 0.28) return { name: 'Pinch', key: 'pinch', pinch, extended };
  if (count >= 4) return { name: 'Mão aberta', key: 'open', pinch, extended };
  if (extended[1] && extended[2] && !extended[3] && !extended[4]) return { name: 'Paz', key: 'peace', pinch, extended };
  if (extended[1] && !extended[2] && !extended[3] && !extended[4]) return { name: 'Apontando', key: 'point', pinch, extended };
  if (thumbOut && count <= 2 && p[4].y < p[3].y) return { name: 'Joinha', key: 'thumbs-up', pinch, extended };
  if (count <= 1) return { name: 'Punho fechado', key: 'fist', pinch, extended };
  if (count >= 3 && !extended[1]) return { name: 'Agarrar', key: 'grab', pinch, extended };
  return { name: 'Neutro', key: 'neutral', pinch, extended };
}
