import * as THREE from 'three';
import { TemporalPoseEngine } from './temporal-engine.js';
import { classifyGesture } from './gesture-engine.js';
import { BlurAnalyzer } from './blur-analyzer.js';
import { BenchmarkRecorder } from './benchmark.js';
import { DeveloperBridge } from './developer-bridge.js';
import { getNativeCamera2Diagnostics } from './native-diagnostics.js';
import './style.css';

const VERSION = '0.2.1';
const MODEL_VERSION = '1.2.2';
const CONNECTIONS = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8],
  [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16],
  [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];
const FINGER_CHAINS = [[0, 1, 2, 3, 4], [0, 5, 6, 7, 8], [0, 9, 10, 11, 12], [0, 13, 14, 15, 16], [0, 17, 18, 19, 20]];
const $ = (id) => document.getElementById(id);
const els = Object.fromEntries([
  'cameraVideo', 'overlayCanvas', 'cameraStage', 'cameraPlaceholder', 'startButton', 'stopButton', 'cameraError', 'cameraSelect',
  'modeSelect', 'model3DMode', 'handsSelect', 'rateSelect', 'runtimeMode', 'holdSelect', 'confidenceSlider', 'confidenceSliderValue',
  'mirrorToggle', 'jointsToggle', 'adaptiveExposureToggle', 'blurAssistToggle', 'flipButton', 'sessionStatus', 'statusText', 'cameraTag',
  'cameraFooterText', 'inputResolution', 'captureRate', 'trackedCount', 'runtimeHud', 'fpsValue', 'inferenceValue', 'pipelineValue',
  'confidenceValue', 'handsValue', 'speedValue', 'fpsHint', 'confidenceHint', 'handsHint', 'speedHint', 'threeMount', 'threeEmpty',
  'worldStatus', 'jointCount', 'diagResolution', 'diagCameraFps', 'diagDelegate', 'diagExposure', 'diagWebGpu', 'diagSecure',
  'diagCores', 'diagMemory', 'diagCameraCount', 'delegateTag', 'eventList', 'resetButton', 'clearLogButton', 'sharpnessValue',
  'blurRiskValue', 'occlusionValue', 'rollingValue', 'motionNote', 'gestureList', 'palmWidthInput', 'calibrateButton',
  'calibrationStatus', 'wmmStatus', 'benchmarkStart', 'benchmarkStop', 'benchmarkSummary', 'recordPoseButton', 'bridgeStatus',
  'bridgeUrl', 'bridgeConnect', 'bridgeNote',
].map((id) => [id, $(id)]));

let worker = null;
let workerReady = false;
let workerBusy = false;
let workerInitPromise = null;
let stream = null;
let running = false;
let sessionId = 0;
let frameId = 0;
let lastVideoTime = -1;
let lastCaptureAt = 0;
let fpsWindowStart = performance.now();
let detectionsInWindow = 0;
let detectionFps = 0;
let lastInferenceMs = 0;
let lastPipelineMs = 0;
let lastConfidence = null;
let lastObservedHands = [];
let latestHands = [];
let latestGestures = [];
let latestMotion = { meanSpeed: 0, maxSpeed: 0, predictedCount: 0 };
let latestSharpness = { laplacianVariance: null, sharpness: null, lowSharpness: false };
let lastTimestampMs = 0;
let currentCameraCapabilities = {};
let currentCameraSettings = {};
let currentCameraCount = 0;
let nativeCameraReport = null;
let activeDelegate = '—';
let confidenceOverride = null;
let lastModelOptionsAt = 0;
let lastWorkerFrameAt = 0;
let calibrationFactor = 1;
let calibrationProfile = null;
let recording = false;
let recordedFrames = [];
let lastApiEventAt = 0;
let lastBridgeSendAt = 0;

const temporal = new TemporalPoseEngine();
const blurAnalyzer = new BlurAnalyzer();
const benchmark = new BenchmarkRecorder();
const bridge = new DeveloperBridge();

// ---------- 3D articulated landmark renderer ----------
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x0b1119);
const camera3D = new THREE.PerspectiveCamera(38, 1, 0.01, 30);
camera3D.position.set(0, 0.05, 2.7);
const renderer = new THREE.WebGLRenderer({ alpha: false, antialias: true, powerPreference: 'low-power' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.35));
renderer.setClearColor(0x0b1119, 1);
renderer.outputColorSpace = THREE.SRGBColorSpace;
els.threeMount.appendChild(renderer.domElement);
scene.add(new THREE.AmbientLight(0xffffff, 1.35));
const keyLight = new THREE.DirectionalLight(0x76f0c3, 1.1); keyLight.position.set(-1.5, 2, 3); scene.add(keyLight);
const fillLight = new THREE.DirectionalLight(0x6e9fff, 0.65); fillLight.position.set(2, -1, 1); scene.add(fillLight);
const grid = new THREE.GridHelper(3.4, 20, 0x263c4b, 0x1a2935); grid.position.y = -0.72; grid.material.transparent = true; grid.material.opacity = 0.45; scene.add(grid);
scene.add(new THREE.AxesHelper(0.55));
const HAND_COLORS = [0x6df2bf, 0x82a9ff];
const UP = new THREE.Vector3(0, 1, 0);

function createHandGroup(index) {
  const group = new THREE.Group();
  const color = HAND_COLORS[index % HAND_COLORS.length];
  const lineMaterial = new THREE.LineBasicMaterial({ color, transparent: true, opacity: 0.95 });
  const lineGeometry = new THREE.BufferGeometry();
  const linePositions = new Float32Array(CONNECTIONS.length * 6);
  lineGeometry.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
  const lines = new THREE.LineSegments(lineGeometry, lineMaterial);
  lines.frustumCulled = false;
  group.add(lines);

  const jointMaterial = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.16, roughness: 0.42 });
  const jointGeometry = new THREE.SphereGeometry(0.012, 8, 6);
  const joints = Array.from({ length: 21 }, () => { const mesh = new THREE.Mesh(jointGeometry, jointMaterial); group.add(mesh); return mesh; });

  const segmentMaterial = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.12, roughness: 0.48, metalness: 0.02 });
  const segments = CONNECTIONS.map(([a, b]) => {
    const radius = (a === 0 || b === 0 || [5, 9, 13, 17].includes(a)) ? 0.009 : 0.0065;
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radius * 0.88, radius, 1, 7), segmentMaterial);
    group.add(mesh);
    return { mesh, a, b };
  });
  const palmGeometry = new THREE.BufferGeometry();
  palmGeometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(18), 3));
  palmGeometry.setIndex([0, 1, 2, 0, 2, 3, 0, 3, 4, 0, 4, 5, 0, 5, 1]);
  const palmMaterial = new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.055, roughness: 0.7, transparent: true, opacity: 0.34, side: THREE.DoubleSide, depthWrite: false });
  const palm = new THREE.Mesh(palmGeometry, palmMaterial);
  group.add(palm);
  group.visible = false;
  group.scale.setScalar(5.2 * calibrationFactor);
  scene.add(group);
  return { group, lineGeometry, linePositions, lines, joints, segments, palm, palmGeometry };
}
const handGroups = [createHandGroup(0), createHandGroup(1)];
let threeMode = 'skeleton';

function resize3D() {
  const width = Math.max(1, els.threeMount.clientWidth);
  const height = Math.max(1, els.threeMount.clientHeight);
  camera3D.aspect = width / height;
  camera3D.updateProjectionMatrix();
  renderer.setSize(width, height, false);
}
const resizeObserver = new ResizeObserver(resize3D);
resizeObserver.observe(els.threeMount);
resize3D();
let last3DRender = 0;
function render3D(now = 0) {
  requestAnimationFrame(render3D);
  const cap = runtimeTargetRate() >= 50 ? 60 : 30;
  if (now - last3DRender < 1000 / cap) return;
  last3DRender = now;
  renderer.render(scene, camera3D);
}
render3D();

function update3D(hands) {
  handGroups.forEach((entry, index) => {
    const hand = hands?.[index];
    const points = hand?.worldLandmarks?.length >= 21
      ? hand.worldLandmarks
      : hand?.landmarks?.map((p) => ({ x: p.x - 0.5, y: 0.5 - p.y, z: (p.z || 0) * 0.45 }));
    if (!points || points.length < 21) { entry.group.visible = false; return; }
    entry.group.visible = true;
    const side = String(hand.handedness || '').toLowerCase();
    const sideOffset = side.includes('left') ? -0.22 : side.includes('right') ? 0.22 : (index ? 0.22 : -0.22);
    entry.group.position.set(sideOffset, 0.02, 0);
    entry.group.scale.setScalar(5.2 * calibrationFactor);
    entry.group.traverse((object) => {
      if (object.material && 'opacity' in object.material) object.material.opacity = hand.predicted ? Math.max(0.12, hand.opacity * 0.75) : (object === entry.palm ? 0.34 : 0.94);
    });
    let cursor = 0;
    for (const [a, b] of CONNECTIONS) {
      const pa = points[a]; const pb = points[b];
      entry.linePositions[cursor++] = pa.x; entry.linePositions[cursor++] = -pa.y; entry.linePositions[cursor++] = -pa.z;
      entry.linePositions[cursor++] = pb.x; entry.linePositions[cursor++] = -pb.y; entry.linePositions[cursor++] = -pb.z;
    }
    entry.lineGeometry.attributes.position.needsUpdate = true;
    for (let i = 0; i < 21; i += 1) entry.joints[i].position.set(points[i].x, -points[i].y, -points[i].z);
    for (const { mesh, a, b } of entry.segments) {
      const start = new THREE.Vector3(points[a].x, -points[a].y, -points[a].z);
      const end = new THREE.Vector3(points[b].x, -points[b].y, -points[b].z);
      const direction = new THREE.Vector3().subVectors(end, start);
      const length = Math.max(0.0001, direction.length());
      mesh.position.copy(start).add(end).multiplyScalar(0.5);
      mesh.quaternion.setFromUnitVectors(UP, direction.normalize());
      mesh.scale.set(1, length, 1);
    }
    const palmRing = [0, 5, 9, 13, 17].map((pointIndex) => points[pointIndex]);
    const center = palmRing.reduce((acc, p) => ({ x: acc.x + p.x / 5, y: acc.y + p.y / 5, z: acc.z + p.z / 5 }), { x: 0, y: 0, z: 0 });
    const palmVertices = [center, ...palmRing].flatMap((p) => [p.x, -p.y, -p.z]);
    entry.palmGeometry.attributes.position.array.set(palmVertices);
    entry.palmGeometry.attributes.position.needsUpdate = true;
    entry.palmGeometry.computeVertexNormals();
    entry.lines.visible = threeMode === 'skeleton';
    entry.joints.forEach((joint) => { joint.visible = threeMode !== 'realistic' || joint.position.length() > 0; joint.scale.setScalar(threeMode === 'realistic' ? 0.82 : 1); });
    entry.segments.forEach(({ mesh }) => { mesh.visible = threeMode !== 'skeleton'; });
    entry.palm.visible = threeMode === 'realistic';
  });
  const visible = hands?.length || 0;
  els.threeEmpty.classList.toggle('hidden', visible > 0);
  els.worldStatus.textContent = visible ? `WORLD SPACE · ${hands.some((hand) => hand.predicted) ? 'PREDICTED' : 'TRACKING'}` : 'WORLD SPACE · INACTIVE';
  els.jointCount.textContent = visible ? `${visible * 21} / ${visible * 21} JOINTS` : '0 / 21 JOINTS';
}

function drawOverlay(hands) {
  const canvas = els.overlayCanvas;
  const ctx = canvas.getContext('2d');
  const width = els.cameraVideo.videoWidth || 640;
  const height = els.cameraVideo.videoHeight || 480;
  if (canvas.width !== width || canvas.height !== height) { canvas.width = width; canvas.height = height; }
  ctx.clearRect(0, 0, width, height);
  const mode = els.modeSelect.value;
  const showJoints = els.jointsToggle.checked;
  hands.forEach((hand, handIndex) => {
    const landmarks = hand.landmarks;
    if (!landmarks || landmarks.length < 21) return;
    const color = handIndex === 0 ? '#6df2bf' : '#82a9ff';
    const gesture = classifyGesture(landmarks);
    const points = landmarks.map((p) => ({ x: p.x * width, y: p.y * height }));
    ctx.save();
    ctx.globalAlpha = hand.predicted ? Math.max(0.18, hand.opacity * 0.75) : 1;
    ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (hand.predicted) ctx.setLineDash([7, 5]);
    if (mode === 'segments') {
      ctx.shadowColor = color; ctx.shadowBlur = 8; ctx.strokeStyle = color; ctx.lineWidth = Math.max(6, width * 0.007);
      for (const chain of FINGER_CHAINS) { ctx.beginPath(); chain.forEach((pointIndex, position) => position ? ctx.lineTo(points[pointIndex].x, points[pointIndex].y) : ctx.moveTo(points[pointIndex].x, points[pointIndex].y)); ctx.stroke(); }
      ctx.shadowBlur = 0;
    } else {
      ctx.shadowColor = color; ctx.shadowBlur = mode === 'combined' ? 7 : 4; ctx.strokeStyle = color;
      ctx.lineWidth = mode === 'combined' ? Math.max(2.4, width * 0.0027) : Math.max(1.8, width * 0.0021);
      for (const [a, b] of CONNECTIONS) { ctx.beginPath(); ctx.moveTo(points[a].x, points[a].y); ctx.lineTo(points[b].x, points[b].y); ctx.stroke(); }
      ctx.shadowBlur = 0;
    }
    ctx.setLineDash([]);
    if (showJoints || mode === 'combined') points.forEach((point, pointIndex) => {
      ctx.beginPath(); ctx.fillStyle = '#0b1119'; ctx.arc(point.x, point.y, pointIndex === 0 ? 5.1 : 3.6, 0, Math.PI * 2); ctx.fill();
      ctx.lineWidth = 1.7; ctx.strokeStyle = color; ctx.stroke(); ctx.beginPath(); ctx.fillStyle = color;
      ctx.arc(point.x, point.y, pointIndex === 0 ? 2.4 : 1.6, 0, Math.PI * 2); ctx.fill();
    });
    const label = `${hand.handedness || `HAND ${handIndex + 1}`} · ${gesture.name}${hand.predicted ? ' · PREDICTED' : ''}`;
    const anchor = points[0];
    ctx.font = `600 ${Math.max(11, width * 0.015)}px system-ui, sans-serif`;
    ctx.fillStyle = color; ctx.shadowColor = '#000'; ctx.shadowBlur = 5;
    ctx.fillText(label, anchor.x + 10, anchor.y + 21);
    if (gesture.key === 'pinch') {
      const mid = { x: (points[4].x + points[8].x) / 2, y: (points[4].y + points[8].y) / 2 };
      ctx.beginPath(); ctx.fillStyle = '#ffffff'; ctx.arc(mid.x, mid.y, Math.max(7, width * 0.008), 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  });
}

// ---------- State, logging, and downloads ----------
const currentState = { running: false, fps: 0, inferenceMs: null, pipelineMs: null, hands: [], gestures: [], motion: {}, blur: {}, camera: {}, runtime: 'adaptive', controller: null };
function setStatus(kind, text) { els.sessionStatus.className = `session-status ${kind}`; els.statusText.textContent = text; }
function logEvent(message, type = 'normal') {
  const row = document.createElement('div'); row.className = `event-row ${type === 'warning' ? 'warning-event' : type === 'success' ? 'success-event' : ''}`;
  const time = document.createElement('span'); time.className = 'event-time'; time.textContent = new Date().toLocaleTimeString('pt-BR', { hour12: false });
  const pip = document.createElement('span'); pip.className = 'event-pip'; const text = document.createElement('span'); text.textContent = message;
  row.append(time, pip, text); els.eventList.prepend(row); while (els.eventList.children.length > 18) els.eventList.lastElementChild.remove();
}
function showError(message) { els.cameraError.textContent = message; els.cameraError.hidden = false; }
function clearError() { els.cameraError.hidden = true; els.cameraError.textContent = ''; }
function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob); const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function downloadText(filename, text, type = 'text/plain;charset=utf-8') { downloadBlob(filename, new Blob([text], { type })); }

function updateStateEvent() {
  const now = performance.now();
  if (now - lastApiEventAt < 20) return;
  lastApiEventAt = now;
  const detail = structuredCloneSafe(currentState);
  window.dispatchEvent(new CustomEvent('vrbox:frame', { detail }));
}
function structuredCloneSafe(value) { try { return structuredClone(value); } catch { return JSON.parse(JSON.stringify(value)); } }

// ---------- Camera diagnostics and capabilities ----------
function updateCameraDiagnostics() {
  const track = stream?.getVideoTracks?.()[0];
  if (!track) return;
  currentCameraSettings = track.getSettings?.() || {};
  currentCameraCapabilities = track.getCapabilities?.() || {};
  const settings = currentCameraSettings;
  const capabilities = currentCameraCapabilities;
  const resolution = settings.width && settings.height ? `${settings.width} × ${settings.height}` : 'Não informado';
  const fps = settings.frameRate ? `${Number(settings.frameRate).toFixed(1)} FPS` : 'Não informado';
  els.inputResolution.textContent = resolution; els.captureRate.textContent = fps;
  els.diagResolution.textContent = resolution; els.diagCameraFps.textContent = fps;
  const exposureModes = Array.isArray(capabilities.exposureMode) ? capabilities.exposureMode : [];
  const exposureSupport = exposureModes.includes('manual') && capabilities.exposureTime;
  const nativeManual = nativeCameraReport?.cameras?.some((camera) => camera.manualSensor);
  els.diagExposure.textContent = exposureSupport ? 'Manual anunciado pela API web' : (nativeManual ? 'Camera2 manual disponível · stream web não controlado' : 'Não exposto / não suportado');
  els.diagExposure.className = exposureSupport || nativeManual ? 'good-value' : 'warn-value';
  currentState.camera = { ...settings, exposureManualAvailable: Boolean(exposureSupport), cameraCount: currentCameraCount };
}

async function populateCameras() {
  if (!navigator.mediaDevices?.enumerateDevices) return;
  try {
    const devices = await navigator.mediaDevices.enumerateDevices();
    const cameras = devices.filter((device) => device.kind === 'videoinput');
    currentCameraCount = cameras.length; els.diagCameraCount.textContent = String(cameras.length);
    const selected = els.cameraSelect.value; els.cameraSelect.replaceChildren();
    cameras.forEach((device, index) => { const option = document.createElement('option'); option.value = device.deviceId; option.textContent = device.label || `Câmera ${index + 1}`; els.cameraSelect.append(option); });
    if (selected && cameras.some((camera) => camera.deviceId === selected)) els.cameraSelect.value = selected;
    if (cameras.length > 1) logEvent(`${cameras.length} câmeras disponíveis. Fusão simultânea ainda não ativada.`, 'success');
  } catch (error) { console.warn('Camera enumeration unavailable:', error); }
}

async function attemptFastCameraMode() {
  const track = stream?.getVideoTracks?.()[0];
  if (!track) return;
  const capabilities = track.getCapabilities?.() || {};
  const attempts = [];
  try {
    await track.applyConstraints({ frameRate: { ideal: 60, max: 60 } });
    attempts.push('solicitação de 60 FPS enviada');
  } catch (error) { attempts.push(`60 FPS recusado (${error.name || 'erro'})`); }
  const modes = Array.isArray(capabilities.exposureMode) ? capabilities.exposureMode : [];
  const exposureRange = capabilities.exposureTime;
  const exposureMin = typeof exposureRange === 'object' && Number.isFinite(exposureRange?.min) ? exposureRange.min : null;
  const manual = {};
  if (modes.includes('manual')) manual.exposureMode = 'manual';
  if (exposureMin !== null) manual.exposureTime = exposureMin;
  const isoRange = capabilities.iso;
  if (isoRange && typeof isoRange === 'object' && Number.isFinite(isoRange.min) && Number.isFinite(isoRange.max)) {
    manual.iso = Math.round(isoRange.min + (isoRange.max - isoRange.min) * 0.55);
  }
  let exposureApplied = false;
  if (els.adaptiveExposureToggle.checked && Object.keys(manual).length) {
    try { await track.applyConstraints({ advanced: [manual] }); exposureApplied = true; attempts.push('perfil manual de exposição aceito pela API'); }
    catch (error) { attempts.push(`exposição manual não aplicada (${error.name || 'erro'})`); }
  }
  updateCameraDiagnostics();
  els.diagExposure.textContent = exposureApplied ? 'Manual aplicado (revalidar settings)' : (Object.keys(manual).length ? 'Manual anunciado, aplicação falhou' : 'Não exposto / não suportado');
  els.diagExposure.className = exposureApplied ? 'good-value' : 'warn-value';
  logEvent(`FMM-inspired: ${attempts.join('; ')}.`, exposureApplied ? 'success' : 'warning');
}

// ---------- Vision worker ----------
function ensureVisionWorker() {
  if (workerReady) return Promise.resolve();
  if (workerInitPromise) return workerInitPromise;
  workerInitPromise = new Promise((resolve, reject) => {
    worker = new Worker(new URL('./vision.worker.js', import.meta.url), { type: 'module' });
    const timeout = window.setTimeout(() => reject(new Error('O modelo demorou demais para inicializar. Verifique a internet e tente novamente.')), 90000);
    worker.onmessage = (event) => {
      const message = event.data || {};
      if (message.type === 'READY') {
        clearTimeout(timeout); workerReady = true; activeDelegate = message.delegate;
        els.diagDelegate.textContent = activeDelegate; els.delegateTag.textContent = `${activeDelegate} MODEL`;
        logEvent(`Hand Landmarker pronto no Worker (${activeDelegate}).`, 'success'); resolve();
      } else if (message.type === 'FATAL') {
        clearTimeout(timeout); const failure = new Error(message.message || 'Falha ao carregar o modelo.');
        if (workerReady) { logEvent(failure.message, 'warning'); showError(failure.message); stopCamera(true); } else reject(failure);
      } else if (message.type === 'RESULT') {
        workerBusy = false;
        if (!running || message.sessionId !== sessionId) return;
        lastInferenceMs = message.processingMs;
        lastPipelineMs = Math.max(0, performance.now() - message.sentAt);
        const raw = { landmarks: message.landmarks || [], worldLandmarks: message.worldLandmarks || [], handedness: message.handedness || [] };
        lastObservedHands = raw.landmarks;
        latestSharpness = blurAnalyzer.analyze(els.cameraVideo);
        const blurRisk = Boolean(els.blurAssistToggle.checked && latestSharpness.lowSharpness && temporal.lastMeanSpeed > 0.18);
        const temporalResult = temporal.update(raw, performance.now(), { responsive: blurRisk || els.runtimeMode.value === 'fmm' });
        latestHands = temporalResult.hands;
        latestMotion = temporalResult;
        latestGestures = latestHands.map((hand) => ({ ...classifyGesture(hand.landmarks), handedness: hand.handedness, predicted: hand.predicted }));
        drawOverlay(latestHands); update3D(latestHands); updateMetrics(raw, temporalResult, blurRisk);
        detectionsInWindow += 1;
        const now = performance.now(); const elapsed = now - fpsWindowStart;
        if (elapsed >= 1000) {
          detectionFps = detectionsInWindow * 1000 / elapsed; detectionsInWindow = 0; fpsWindowStart = now;
          els.fpsValue.innerHTML = `${detectionFps.toFixed(1)}<small> FPS</small>`;
          els.fpsHint.textContent = detectionFps >= 24 ? 'Taxa de inferência estável' : 'Abaixo de 24 FPS nesta janela';
        }
        updateGestureUI(); updateMotionUI(blurRisk); updateRecording(raw);
        if (benchmark.active) benchmark.add({ fps: detectionFps || 0, inferenceMs: lastInferenceMs, pipelineMs: lastPipelineMs, hands: raw.landmarks.length, confidence: lastConfidence ?? '', motionSpeed: temporalResult.meanSpeed, sharpness: latestSharpness.sharpness ?? '', blurRisk: blurRisk ? 1 : 0, predictedHands: temporalResult.predictedCount });
        currentState.running = true; currentState.fps = detectionFps; currentState.inferenceMs = lastInferenceMs; currentState.pipelineMs = lastPipelineMs;
        currentState.hands = latestHands.map((hand, index) => ({ handedness: hand.handedness, landmarks: hand.landmarks, worldLandmarks: hand.worldLandmarks, confidence: hand.confidence, predicted: hand.predicted, gesture: latestGestures[index]?.key }));
        currentState.gestures = latestGestures; currentState.motion = { meanSpeed: temporalResult.meanSpeed, maxSpeed: temporalResult.maxSpeed, predictedCount: temporalResult.predictedCount };
        currentState.blur = { ...latestSharpness, blurRisk }; currentState.runtime = els.runtimeMode.value;
        updateStateEvent(); sendBridgeFrame(); maybeAdjustModelThreshold(blurRisk, temporalResult.meanSpeed);
      } else if (message.type === 'INFERENCE_ERROR') {
        workerBusy = false; if (message.sessionId === sessionId) logEvent(`Erro de inferência: ${message.message}`, 'warning');
      } else if (message.type === 'OPTIONS_OK') {
        // Options were applied by the worker.
      } else if (message.type === 'WARNING') logEvent(`Aviso do modelo: ${message.message}`, 'warning');
    };
    worker.onerror = (event) => {
      clearTimeout(timeout); workerBusy = false; const failure = new Error(event.message || 'O Worker de visão falhou.');
      if (workerReady) { logEvent(failure.message, 'warning'); showError(failure.message); stopCamera(true); } else reject(failure);
    };
    worker.postMessage({ type: 'INIT', numHands: Number(els.handsSelect.value), minConfidence: Number(els.confidenceSlider.value) / 100 });
  }).catch((error) => {
    workerInitPromise = null; worker?.terminate(); worker = null; workerReady = false; throw error;
  });
  return workerInitPromise;
}

function maybeAdjustModelThreshold(blurRisk, speed) {
  const now = performance.now();
  if (!workerReady || now - lastModelOptionsAt < 1200) return;
  const base = Number(els.confidenceSlider.value) / 100;
  const next = blurRisk && speed > 0.18 ? Math.max(0.28, base - 0.08) : base;
  if (confidenceOverride === null || Math.abs(confidenceOverride - next) >= 0.035) {
    confidenceOverride = next; lastModelOptionsAt = now;
    worker?.postMessage({ type: 'OPTIONS', options: { minHandDetectionConfidence: next, minHandPresenceConfidence: blurRisk ? 0.38 : 0.5, minTrackingConfidence: blurRisk ? 0.38 : 0.5 } });
  }
}

function runtimeTargetRate() {
  const mode = els.runtimeMode?.value || 'adaptive';
  if (mode === 'fmm') return 60;
  if (mode === 'balanced') return 30;
  if (mode === 'precision') return 24;
  if (mode === 'eco') return 15;
  const max = Number(els.rateSelect?.value || 30);
  if (lastInferenceMs > 28) return Math.min(max, 20);
  if (latestMotion.maxSpeed > 0.24 && lastInferenceMs < 24) return max;
  return Math.min(max, 30);
}

// ---------- Camera session ----------
async function startCamera() {
  if (!window.isSecureContext) { showError('A câmera exige HTTPS ou localhost. Publique o site em HTTPS para testar no celular.'); return; }
  if (!navigator.mediaDevices?.getUserMedia) { showError('Este navegador não disponibiliza a câmera. Tente o Chrome atualizado.'); return; }
  clearError(); els.startButton.disabled = true; els.startButton.innerHTML = '<span class="spinner"></span> INICIANDO…'; setStatus('loading', 'INICIALIZANDO CÂMERA');
  try {
    const deviceId = els.cameraSelect.value;
    const video = { width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 60, max: 60 }, ...(deviceId ? { deviceId: { exact: deviceId } } : { facingMode: 'user' }) };
    stream = await navigator.mediaDevices.getUserMedia({ video, audio: false });
    els.cameraVideo.srcObject = stream; await els.cameraVideo.play(); await populateCameras(); updateCameraDiagnostics();
    await refreshNativeCameraDiagnostics();
    if (!workerReady) { els.cameraFooterText.textContent = 'Carregando modelo neural…'; await ensureVisionWorker(); }
    running = true; sessionId += 1; lastVideoTime = -1; detectionsInWindow = 0; detectionFps = 0; fpsWindowStart = performance.now(); lastCaptureAt = 0; temporal.reset();
    els.cameraPlaceholder.classList.add('hidden'); els.cameraTag.textContent = 'LIVE INPUT'; els.cameraTag.classList.add('tag-live');
    els.cameraFooterText.textContent = 'Captura ativa · inferência local'; els.stopButton.disabled = false; els.startButton.disabled = true; els.startButton.innerHTML = '<span>●</span> RASTREAMENTO ATIVO';
    setStatus('active', 'RASTREAMENTO ATIVO'); logEvent(`Câmera iniciada: ${currentCameraSettings.width || '?'}×${currentCameraSettings.height || '?'} @ ${currentCameraSettings.frameRate || '?'} FPS.`, 'success');
    if (els.runtimeMode.value === 'fmm') await attemptFastCameraMode();
    requestAnimationFrame(processFrame);
  } catch (error) {
    console.error(error); stopCamera(false); showError(humanizeCameraError(error)); setStatus('error', 'FALHA AO INICIAR'); logEvent(`Falha ao iniciar: ${error?.message || error}`, 'warning');
  } finally {
    if (!running) { els.startButton.disabled = false; els.startButton.innerHTML = '<span>▶</span> INICIAR RASTREAMENTO'; }
  }
}
function humanizeCameraError(error) {
  if (error?.name === 'NotAllowedError' || error?.name === 'PermissionDeniedError') return 'Permissão da câmera negada. Libere a câmera nas permissões do navegador e tente novamente.';
  if (error?.name === 'NotFoundError' || error?.name === 'DevicesNotFoundError') return 'Nenhuma câmera compatível foi encontrada.';
  if (error?.name === 'NotReadableError' || error?.name === 'TrackStartError') return 'A câmera está ocupada por outro aplicativo ou não pôde ser iniciada.';
  if (error?.name === 'OverconstrainedError') return 'A câmera não aceitou as configurações solicitadas. Tente outra câmera ou resolução.';
  return `Não foi possível iniciar o rastreamento. ${error?.message || 'Verifique a câmera e a conexão.'}`;
}
function stopCamera(updateStatus = true) {
  running = false; sessionId += 1;
  if (stream) stream.getTracks().forEach((track) => track.stop()); stream = null; els.cameraVideo.srcObject = null;
  const ctx = els.overlayCanvas.getContext('2d'); ctx.clearRect(0, 0, els.overlayCanvas.width, els.overlayCanvas.height);
  latestHands = []; latestGestures = []; lastObservedHands = []; temporal.reset(); update3D([]);
  els.trackedCount.textContent = '00 HANDS'; els.handsValue.innerHTML = '0<small> / 2</small>'; els.handsHint.textContent = 'Nenhuma mão identificada';
  els.cameraTag.textContent = 'NO SIGNAL'; els.cameraTag.classList.remove('tag-live'); els.cameraPlaceholder.classList.remove('hidden');
  els.stopButton.disabled = true; els.startButton.disabled = false; els.startButton.innerHTML = '<span>▶</span> INICIAR RASTREAMENTO'; els.cameraFooterText.textContent = 'Aguardando permissão da câmera';
  currentState.running = false; currentState.hands = [];
  if (updateStatus) { setStatus('', 'SISTEMA EM ESPERA'); logEvent('Sessão encerrada.'); }
}

function processFrame(now) {
  if (!running || !workerReady) return;
  const video = els.cameraVideo;
  const targetRate = runtimeTargetRate();
  const targetInterval = 1000 / targetRate;
  if (video.readyState >= 2 && video.currentTime !== lastVideoTime && !workerBusy && now - lastCaptureAt >= targetInterval) {
    lastVideoTime = video.currentTime; lastCaptureAt = now; workerBusy = true;
    const currentFrameId = ++frameId; const activeSession = sessionId; const sentAt = performance.now();
    const timestampMs = Math.max(performance.now(), lastTimestampMs + 1); lastTimestampMs = timestampMs;
    const sourceWidth = video.videoWidth || 960;
    const sourceHeight = video.videoHeight || 540;
    const scale = Math.min(1, 960 / sourceWidth, 540 / sourceHeight);
    createImageBitmap(video, { resizeWidth: Math.max(1, Math.round(sourceWidth * scale)), resizeHeight: Math.max(1, Math.round(sourceHeight * scale)), resizeQuality: 'high' }).then((bitmap) => {
      if (!running || activeSession !== sessionId || !worker) { bitmap.close?.(); workerBusy = false; return; }
      worker.postMessage({ type: 'FRAME', bitmap, timestampMs, frameId: currentFrameId, sessionId: activeSession, sentAt }, [bitmap]);
    }).catch((error) => { workerBusy = false; if (running && activeSession === sessionId) logEvent(`Falha ao copiar frame: ${error.message}`, 'warning'); });
  }
  requestAnimationFrame(processFrame);
}

// ---------- Metrics and diagnostics ----------
function updateMetrics(raw, temporalResult, blurRisk) {
  const count = raw.landmarks?.length || 0;
  const scores = (raw.handedness || []).map((entries) => entries?.[0]?.score).filter(Number.isFinite);
  const confidence = scores.length ? scores.reduce((sum, score) => sum + score, 0) / scores.length : null;
  lastConfidence = confidence;
  els.inferenceValue.innerHTML = `${lastInferenceMs.toFixed(1)}<small> ms</small>`;
  els.pipelineValue.innerHTML = `${lastPipelineMs.toFixed(1)}<small> ms</small>`;
  els.confidenceValue.innerHTML = confidence === null ? `—<small> %</small>` : `${Math.round(confidence * 100)}<small> %</small>`;
  els.confidenceHint.textContent = confidence === null ? 'Sem pontuação disponível' : `${scores.length} mão(s) observadas`;
  els.handsValue.innerHTML = `${temporalResult.displayedCount}<small> / 2</small>`;
  els.handsHint.textContent = `${count} reais · ${temporalResult.predictedCount} extrapoladas`;
  els.trackedCount.textContent = `${String(temporalResult.displayedCount).padStart(2, '0')} HAND${temporalResult.displayedCount === 1 ? '' : 'S'}`;
  els.speedValue.innerHTML = `${temporalResult.meanSpeed.toFixed(2)}<small> u/s</small>`;
  els.speedHint.textContent = temporalResult.maxSpeed > 0.24 ? 'Movimento rápido' : 'Velocidade normalizada da imagem';
  if (count === 0 && temporalResult.predictedCount) els.wmmStatus.textContent = `Pose extrapolada · ${temporal.holdMs} ms`; else els.wmmStatus.textContent = count ? 'Mãos dentro da imagem' : 'Aguardando rastreamento';
  els.runtimeHud.textContent = `${els.runtimeMode.value.toUpperCase()} · ${runtimeTargetRate()} FPS`;
  if (blurRisk) els.motionNote.textContent = 'Risco heurístico de blur: nitidez baixa + movimento rápido. A compensação temporal está em prioridade responsiva; detalhes não capturados não podem ser recuperados.';
  else els.motionNote.textContent = 'O analisador de nitidez usa variância do Laplaciano: é um proxy de imagem, não um detector neural conclusivo de motion blur.';
}

function updateMotionUI(blurRisk) {
  const sharpness = latestSharpness.sharpness;
  els.sharpnessValue.textContent = Number.isFinite(sharpness) ? `${sharpness.toFixed(0)} / 100` : '—';
  els.blurRiskValue.textContent = blurRisk ? 'ELEVADO' : (latestSharpness.lowSharpness ? 'NITIDEZ BAIXA' : 'NORMAL');
  els.blurRiskValue.className = blurRisk || latestSharpness.lowSharpness ? 'warn-text' : 'good-text';
  els.occlusionValue.textContent = latestMotion.predictedCount ? `${latestMotion.predictedCount} PREDICTED` : 'NONE';
  const exposureMs = Number(currentCameraSettings.exposureTime);
  const motionFast = latestMotion.maxSpeed > 0.35;
  const cameraFps = Number(currentCameraSettings.frameRate || 0);
  els.rollingValue.textContent = motionFast && (!cameraFps || cameraFps <= 30) ? 'POSSIBLE RISK' : 'NOT MEASURED';
}

function updateGestureUI() {
  const bySide = new Map(latestGestures.map((gesture) => [String(gesture.handedness).toLowerCase(), gesture]));
  const makeRow = (side, key) => {
    const gesture = bySide.get(side) || latestGestures[key];
    const title = gesture ? gesture.name : '—'; const detail = gesture ? `${Math.round(gesture.pinch * 100)}% pinch${gesture.predicted ? ' · predicted' : ''}` : 'Sem mão';
    return `<div class="gesture-row"><span>${side.toUpperCase()}</span><strong>${title}</strong><small>${detail}</small></div>`;
  };
  els.gestureList.innerHTML = `${makeRow('left', 0)}${makeRow('right', 1)}`;
}

// ---------- Calibration, benchmark, recording and developer bridge ----------
function calibrateHand() {
  const hand = latestHands.find((item) => !item.predicted && item.worldLandmarks?.length >= 21);
  const desiredCm = Number(els.palmWidthInput.value);
  if (!hand) { els.calibrationStatus.textContent = 'Mostre uma mão para a câmera antes de calibrar.'; return; }
  if (!Number.isFinite(desiredCm) || desiredCm < 4 || desiredCm > 14) { els.calibrationStatus.textContent = 'Informe uma largura de palma entre 4 e 14 cm.'; return; }
  const a = hand.worldLandmarks[5]; const b = hand.worldLandmarks[17];
  const measured = Math.hypot(a.x - b.x, a.y - b.y, a.z - b.z);
  if (!Number.isFinite(measured) || measured < 0.001) { els.calibrationStatus.textContent = 'Não foi possível medir a palma nesta pose.'; return; }
  calibrationFactor = (desiredCm / 100) / measured;
  calibrationProfile = { targetPalmWidthCm: desiredCm, estimatedWorldSpan: measured, visualScaleFactor: calibrationFactor, calibratedAt: new Date().toISOString() };
  localStorage.setItem('vrbox-hand-calibration', JSON.stringify(calibrationProfile));
  update3D(latestHands); els.calibrationStatus.textContent = `Perfil salvo. Fator visual ${calibrationFactor.toFixed(2)}×. Não representa medida de profundidade validada.`;
  logEvent('Perfil de escala visual da mão calibrado e salvo localmente.', 'success');
}
function sendBridgeFrame() {
  const now = performance.now(); if (now - lastBridgeSendAt < 25) return; lastBridgeSendAt = now;
  bridge.send({ type: 'vrbox.handtracking.frame', version: 1, timestamp: new Date().toISOString(), metrics: { fps: detectionFps, inferenceMs: lastInferenceMs, pipelineMs: lastPipelineMs }, hands: currentState.hands, gestures: currentState.gestures });
}
bridge.addEventListener('status', (event) => {
  els.bridgeStatus.textContent = event.detail.toUpperCase();
  els.bridgeNote.textContent = event.detail === 'connected' ? `Conectado a ${bridge.url}` : (event.detail === 'error' ? 'Falha na conexão WebSocket.' : 'Aguardando conexão opcional.');
  logEvent(`Developer Bridge: ${event.detail}.`, event.detail === 'connected' ? 'success' : event.detail === 'error' ? 'warning' : 'normal');
});
bridge.addEventListener('message', (event) => {
  const payload = event.detail;
  if (payload?.type === 'vrbox.controller' || payload?.type === 'vrbox.input') {
    currentState.controller = payload.data || payload;
    logEvent('Entrada externa recebida pela Developer Bridge.', 'success');
    window.dispatchEvent(new CustomEvent('vrbox:controller', { detail: payload }));
  }
});

function updateRecording(raw) {
  if (!recording) return;
  if (recordedFrames.length >= 5400) { recording = false; els.recordPoseButton.textContent = 'GRAVAR POSES JSON'; logEvent('Gravação encerrada automaticamente: limite de amostras atingido.', 'warning'); return; }
  recordedFrames.push({ at: new Date().toISOString(), hands: raw.landmarks, worldLandmarks: raw.worldLandmarks, handedness: raw.handedness });
}

// ---------- Events ----------
els.startButton.addEventListener('click', startCamera);
els.stopButton.addEventListener('click', () => stopCamera(true));
els.flipButton.addEventListener('click', () => { els.mirrorToggle.checked = !els.mirrorToggle.checked; applyMirror(); });
function applyMirror() { const transform = els.mirrorToggle.checked ? 'scaleX(-1)' : 'none'; els.cameraVideo.style.transform = transform; els.overlayCanvas.style.transform = transform; }
els.mirrorToggle.addEventListener('change', applyMirror);
els.modeSelect.addEventListener('change', () => { if (running) drawOverlay(latestHands); });
els.model3DMode.addEventListener('change', () => { threeMode = els.model3DMode.value; update3D(latestHands); });
els.handsSelect.addEventListener('change', () => worker?.postMessage({ type: 'OPTIONS', options: { numHands: Number(els.handsSelect.value) } }));
els.confidenceSlider.addEventListener('input', () => { els.confidenceSliderValue.textContent = `${els.confidenceSlider.value}%`; });
els.confidenceSlider.addEventListener('change', () => {
  confidenceOverride = Number(els.confidenceSlider.value) / 100;
  worker?.postMessage({ type: 'OPTIONS', options: { minHandDetectionConfidence: confidenceOverride, minHandPresenceConfidence: confidenceOverride, minTrackingConfidence: confidenceOverride } });
});
els.cameraSelect.addEventListener('change', async () => { if (!running) return; stopCamera(false); await startCamera(); });
els.runtimeMode.addEventListener('change', async () => {
  els.runtimeHud.textContent = `${els.runtimeMode.value.toUpperCase()} · ${runtimeTargetRate()} FPS`;
  if (running && els.runtimeMode.value === 'fmm') await attemptFastCameraMode();
  logEvent(`Runtime alterado: ${els.runtimeMode.value}. Taxa-alvo ${runtimeTargetRate()} FPS; taxa física depende da câmera.`);
});
els.holdSelect.addEventListener('change', () => { temporal.setParameters({ holdMs: Number(els.holdSelect.value) }); logEvent(`Janela de extrapolação ajustada para ${els.holdSelect.value} ms.`); });
els.blurAssistToggle.addEventListener('change', () => logEvent(`Blur-aware assist ${els.blurAssistToggle.checked ? 'ativado' : 'desativado'}.`));
els.adaptiveExposureToggle.addEventListener('change', async () => { if (running && els.runtimeMode.value === 'fmm' && els.adaptiveExposureToggle.checked) await attemptFastCameraMode(); });
els.resetButton.addEventListener('click', () => {
  detectionFps = 0; lastInferenceMs = 0; lastPipelineMs = 0; lastConfidence = null; detectionsInWindow = 0; fpsWindowStart = performance.now();
  els.fpsValue.innerHTML = '—<small> FPS</small>'; els.inferenceValue.innerHTML = '—<small> ms</small>'; els.pipelineValue.innerHTML = '—<small> ms</small>'; els.confidenceValue.innerHTML = '—<small> %</small>';
  logEvent('Métricas reiniciadas.');
});
els.clearLogButton.addEventListener('click', () => { els.eventList.replaceChildren(); logEvent('Log limpo.'); });
els.calibrateButton.addEventListener('click', calibrateHand);
els.benchmarkStart.addEventListener('click', () => {
  if (!running) { els.benchmarkSummary.textContent = 'Inicie a câmera antes de gravar um benchmark.'; return; }
  benchmark.start(); els.benchmarkStart.disabled = true; els.benchmarkStop.disabled = false; els.benchmarkSummary.textContent = 'Benchmark em andamento. Faça movimentos lentos, rápidos e oclusões controladas.'; logEvent('Benchmark iniciado.', 'success');
});
els.benchmarkStop.addEventListener('click', () => {
  const summary = benchmark.stop(); els.benchmarkStart.disabled = false; els.benchmarkStop.disabled = true;
  els.benchmarkSummary.textContent = `${summary.samples} amostras · inferência mediana ${summary.inferenceMedian?.toFixed(1) ?? '—'} ms · p95 ${summary.inferenceP95?.toFixed(1) ?? '—'} ms · pipeline mediano ${summary.pipelineMedian?.toFixed(1) ?? '—'} ms.`;
  downloadText(`vrbox-benchmark-${Date.now()}.csv`, benchmark.toCSV(), 'text/csv;charset=utf-8'); logEvent(`Benchmark exportado: ${summary.samples} amostras.`, 'success');
});
els.recordPoseButton.addEventListener('click', () => {
  if (!recording) { recording = true; recordedFrames = []; els.recordPoseButton.textContent = 'PARAR E EXPORTAR JSON'; logEvent('Gravação de poses iniciada.', 'success'); }
  else { recording = false; els.recordPoseButton.textContent = 'GRAVAR POSES JSON'; downloadText(`vrbox-poses-${Date.now()}.json`, JSON.stringify({ schema: 'vrbox-pose-recording-v1', frames: recordedFrames }, null, 2), 'application/json'); logEvent(`Gravação JSON exportada: ${recordedFrames.length} frames.`, 'success'); }
});
els.bridgeConnect.addEventListener('click', () => {
  if (bridge.status === 'connected' || bridge.status === 'connecting') { bridge.disconnect(); els.bridgeStatus.textContent = 'DISCONNECTED'; els.bridgeNote.textContent = 'Bridge desconectada.'; return; }
  try { bridge.connect(els.bridgeUrl.value.trim()); } catch (error) { els.bridgeNote.textContent = error.message; logEvent(error.message, 'warning'); }
});

// ---------- Public browser API ----------
window.VRBoxNeuralTracking = {
  version: VERSION,
  getState: () => structuredCloneSafe(currentState),
  subscribe(callback) {
    if (typeof callback !== 'function') throw new TypeError('callback precisa ser uma função');
    const handler = (event) => callback(event.detail);
    window.addEventListener('vrbox:frame', handler);
    return () => window.removeEventListener('vrbox:frame', handler);
  },
  connectBridge: (url) => bridge.connect(url),
  disconnectBridge: () => bridge.disconnect(),
  onController(callback) {
    const handler = (event) => callback(event.detail);
    window.addEventListener('vrbox:controller', handler);
    return () => window.removeEventListener('vrbox:controller', handler);
  },
};

// ---------- Environment ----------
els.diagSecure.textContent = window.isSecureContext ? 'HTTPS / secure' : 'Not secure';
els.diagSecure.className = window.isSecureContext ? 'good-value' : 'warn-value';
els.diagWebGpu.textContent = navigator.gpu ? 'Available' : 'Not exposed';
els.diagWebGpu.className = navigator.gpu ? 'good-value' : 'warn-value';
els.diagCores.textContent = navigator.hardwareConcurrency ? `${navigator.hardwareConcurrency} logical` : 'Not exposed';
els.diagMemory.textContent = navigator.deviceMemory ? `${navigator.deviceMemory} GB approx.` : 'Not exposed';
els.diagCameraCount.textContent = 'Permission pending';
try {
  const saved = JSON.parse(localStorage.getItem('vrbox-hand-calibration') || 'null');
  if (saved && Number.isFinite(saved.visualScaleFactor)) { calibrationProfile = saved; calibrationFactor = saved.visualScaleFactor; els.calibrationStatus.textContent = `Perfil carregado · palma ${saved.targetPalmWidthCm} cm · escala visual ${calibrationFactor.toFixed(2)}×.`; }
} catch { /* Ignore invalid saved profile. */ }
if (!window.isSecureContext) showError('A câmera só funciona em HTTPS ou localhost. Publique o site com HTTPS para testar no Android.');
if ('serviceWorker' in navigator && import.meta.env.PROD) window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch((error) => console.warn('Service worker registration failed:', error)));
async function refreshNativeCameraDiagnostics() {
  const report = await getNativeCamera2Diagnostics();
  if (!report) return;
  nativeCameraReport = report;
  if (report.error) {
    els.diagCameraCount.textContent = 'Camera2 unavailable';
    logEvent(`Diagnóstico Camera2: ${report.error}`, 'warning');
    return;
  }
  const cameras = report.cameras || [];
  currentCameraCount = cameras.length;
  els.diagCameraCount.textContent = `${cameras.length} · Camera2`;
  const manualSensors = cameras.filter((camera) => camera.manualSensor);
  if (manualSensors.length) {
    const range = manualSensors[0].exposureTimeNs;
    const exposureLabel = range ? `${manualSensors.length} sensor(es) manual · ${Math.round(range.min / 1000)}–${Math.round(range.max / 1000)} µs` : `${manualSensors.length} sensor(es) manual`;
    els.diagExposure.textContent = `${exposureLabel} · não aplicado ao stream`;
    els.diagExposure.className = 'good-value';
  } else {
    els.diagExposure.textContent = 'Camera2: manual sensor não anunciado';
    els.diagExposure.className = 'warn-value';
  }
  logEvent(`Camera2 nativo: ${cameras.length} câmera(s) enumeradas; diagnóstico somente leitura.`, 'success');
}
refreshNativeCameraDiagnostics().catch((error) => console.warn('Native Camera2 diagnostics skipped:', error));
applyMirror(); logEvent(`VRBox Neural Tracking ${VERSION} pronto. MediaPipe Tasks Vision ${MODEL_VERSION} será carregado ao iniciar.`);
window.addEventListener('beforeunload', () => { stopCamera(false); worker?.terminate(); resizeObserver.disconnect(); renderer.dispose(); bridge.disconnect(); });
