import { Capacitor, registerPlugin } from '@capacitor/core';

const Camera2Diagnostics = registerPlugin('Camera2Diagnostics');

export async function getNativeCamera2Diagnostics() {
  if (!Capacitor.isNativePlatform() || Capacitor.getPlatform() !== 'android') return null;
  try { return await Camera2Diagnostics.getCapabilities(); }
  catch (error) { return { error: error?.message || String(error) }; }
}
