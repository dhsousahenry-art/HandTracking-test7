/*
 * VRBox temporal pose engine.
 * Adaptive One-Euro-style filtering + short-horizon constant-velocity recovery.
 * This is a lightweight temporal compensator, not Meta's FMM/WMM implementation.
 */
const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function alpha(cutoff, dt) {
  const tau = 1 / (2 * Math.PI * Math.max(0.01, cutoff));
  return 1 / (1 + tau / Math.max(0.001, dt));
}

class AdaptiveScalarFilter {
  constructor(minCutoff = 1.25, beta = 0.035, derivativeCutoff = 1) {
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.derivativeCutoff = derivativeCutoff;
    this.initialized = false;
    this.value = 0;
    this.derivative = 0;
  }

  update(raw, dt, betaOverride = this.beta) {
    if (!this.initialized) {
      this.initialized = true;
      this.value = raw;
      this.derivative = 0;
      return raw;
    }
    const safeDt = clamp(dt, 1 / 240, 0.1);
    const rawDerivative = (raw - this.value) / safeDt;
    const derivativeAlpha = alpha(this.derivativeCutoff, safeDt);
    this.derivative += derivativeAlpha * (rawDerivative - this.derivative);
    const cutoff = this.minCutoff + betaOverride * Math.abs(this.derivative);
    const valueAlpha = alpha(cutoff, safeDt);
    this.value += valueAlpha * (raw - this.value);
    return this.value;
  }
}

function makePointFilters() {
  return Array.from({ length: 21 }, () => ({
    x: new AdaptiveScalarFilter(),
    y: new AdaptiveScalarFilter(),
    z: new AdaptiveScalarFilter(),
  }));
}

function clonePoints(points = []) {
  return points.map((point) => ({ x: point.x, y: point.y, z: point.z ?? 0 }));
}

export class TemporalPoseEngine {
  constructor({ holdMs = 160, minCutoff = 1.35, beta = 0.035 } = {}) {
    this.holdMs = holdMs;
    this.minCutoff = minCutoff;
    this.beta = beta;
    this.tracks = new Map();
    this.lastUpdateMs = 0;
    this.lastMeanSpeed = 0;
    this.lastMaxSpeed = 0;
  }

  setParameters({ holdMs, minCutoff, beta } = {}) {
    if (Number.isFinite(holdMs)) this.holdMs = clamp(holdMs, 0, 500);
    if (Number.isFinite(minCutoff)) this.minCutoff = clamp(minCutoff, 0.25, 8);
    if (Number.isFinite(beta)) this.beta = clamp(beta, 0, 0.25);
  }

  update(result, nowMs = performance.now(), { responsive = false } = {}) {
    const rawHands = result?.landmarks || [];
    const rawWorld = result?.worldLandmarks || [];
    const handedness = result?.handedness || [];
    const dt = this.lastUpdateMs ? clamp((nowMs - this.lastUpdateMs) / 1000, 1 / 240, 0.1) : 1 / 30;
    this.lastUpdateMs = nowMs;
    const activeKeys = new Set();
    const visible = [];
    const speeds = [];
    const beta = responsive ? this.beta * 2.1 : this.beta;

    rawHands.forEach((landmarks, index) => {
      if (!Array.isArray(landmarks) || landmarks.length < 21) return;
      const side = handedness[index]?.[0]?.categoryName || `hand-${index}`;
      const key = String(side).toLowerCase();
      activeKeys.add(key);
      const track = this.tracks.get(key) || {
        filters: makePointFilters(), previousRaw: null, previousAt: nowMs,
        filtered: null, world: null, worldVelocity: Array.from({ length: 21 }, () => ({ x: 0, y: 0, z: 0 })), velocity: Array.from({ length: 21 }, () => ({ x: 0, y: 0, z: 0 })),
        lastSeen: nowMs, confidence: 0,
      };
      const elapsed = clamp((nowMs - track.previousAt) / 1000, 1 / 240, 0.1);
      const previous = track.filtered;
      const previousWorld = track.world;
      const currentWorld = clonePoints(rawWorld[index] || []);
      const filtered = landmarks.map((point, pointIndex) => {
        const filter = track.filters[pointIndex];
        return {
          x: filter.x.update(point.x, elapsed, beta),
          y: filter.y.update(point.y, elapsed, beta),
          z: filter.z.update(point.z ?? 0, elapsed, beta),
        };
      });
      let speedSum = 0;
      let maxSpeed = 0;
      if (previous) {
        filtered.forEach((point, pointIndex) => {
          const old = previous[pointIndex];
          const vx = (point.x - old.x) / elapsed;
          const vy = (point.y - old.y) / elapsed;
          const vz = ((point.z ?? 0) - (old.z ?? 0)) / elapsed;
          track.velocity[pointIndex] = { x: vx, y: vy, z: vz };
          const speed = Math.hypot(vx, vy);
          speedSum += speed;
          maxSpeed = Math.max(maxSpeed, speed);
        });
      }
      // World-space velocity is estimated independently from normalized image-space velocity.
      // This keeps short 3D recovery in the same coordinate system as MediaPipe world landmarks.
      if (previousWorld?.length === currentWorld.length && currentWorld.length >= 21) {
        currentWorld.forEach((point, pointIndex) => {
          const old = previousWorld[pointIndex];
          track.worldVelocity[pointIndex] = {
            x: (point.x - old.x) / elapsed,
            y: (point.y - old.y) / elapsed,
            z: ((point.z ?? 0) - (old.z ?? 0)) / elapsed,
          };
        });
      }
      const meanSpeed = previous ? speedSum / 21 : 0;
      speeds.push(meanSpeed);
      track.previousRaw = clonePoints(landmarks);
      track.previousAt = nowMs;
      track.filtered = filtered;
      track.world = currentWorld;
      track.lastSeen = nowMs;
      track.confidence = handedness[index]?.[0]?.score ?? 0;
      track.meanSpeed = meanSpeed;
      track.maxSpeed = maxSpeed;
      this.tracks.set(key, track);
      visible.push({
        key, handedness: side, landmarks: filtered, worldLandmarks: track.world,
        confidence: track.confidence, predicted: false, opacity: 1,
        speed: meanSpeed, maxSpeed,
      });
    });

    // A short visual bridge through momentary detector dropouts. It is not true body tracking.
    for (const [key, track] of this.tracks) {
      if (activeKeys.has(key)) continue;
      const ageMs = nowMs - track.lastSeen;
      if (ageMs < 0 || ageMs > this.holdMs || !track.filtered) continue;
      const seconds = ageMs / 1000;
      const predictedLandmarks = track.filtered.map((point, index) => {
        const velocity = track.velocity[index];
        return {
          x: clamp(point.x + velocity.x * seconds, -0.25, 1.25),
          y: clamp(point.y + velocity.y * seconds, -0.25, 1.25),
          z: point.z + velocity.z * seconds,
        };
      });
      const predictedWorld = track.world?.map((point, index) => {
        const velocity = track.worldVelocity[index] || { x: 0, y: 0, z: 0 };
        return { x: point.x + velocity.x * seconds, y: point.y + velocity.y * seconds, z: point.z + velocity.z * seconds };
      }) || [];
      visible.push({
        key, handedness: key, landmarks: predictedLandmarks, worldLandmarks: predictedWorld,
        confidence: track.confidence * (1 - ageMs / this.holdMs), predicted: true,
        opacity: clamp(1 - ageMs / this.holdMs, 0, 1), speed: track.meanSpeed || 0,
        maxSpeed: track.maxSpeed || 0,
      });
    }

    this.lastMeanSpeed = speeds.length ? speeds.reduce((sum, speed) => sum + speed, 0) / speeds.length : 0;
    this.lastMaxSpeed = speeds.length ? Math.max(...speeds) : 0;
    return {
      hands: visible,
      observedCount: rawHands.length,
      displayedCount: visible.length,
      meanSpeed: this.lastMeanSpeed,
      maxSpeed: this.lastMaxSpeed,
      predictedCount: visible.filter((hand) => hand.predicted).length,
    };
  }

  reset() {
    this.tracks.clear();
    this.lastUpdateMs = 0;
    this.lastMeanSpeed = 0;
    this.lastMaxSpeed = 0;
  }
}
