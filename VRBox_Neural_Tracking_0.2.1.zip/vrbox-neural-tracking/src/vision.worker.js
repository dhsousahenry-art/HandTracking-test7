import { FilesetResolver, HandLandmarker } from '@mediapipe/tasks-vision';

const MODEL_VERSION = '1.2.2';
const WASM_URL = `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@${MODEL_VERSION}/wasm`;
const MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
let landmarker = null;
let busy = false;

self.onmessage = async (event) => {
  const message = event.data || {};
  if (message.type === 'INIT') {
    try {
      const vision = await FilesetResolver.forVisionTasks(WASM_URL);
      const options = {
        runningMode: 'VIDEO', numHands: message.numHands || 2,
        minHandDetectionConfidence: message.minConfidence ?? 0.5,
        minHandPresenceConfidence: message.minConfidence ?? 0.5,
        minTrackingConfidence: message.minConfidence ?? 0.5,
        baseOptions: { modelAssetPath: MODEL_URL, delegate: 'GPU' },
      };
      let delegate = 'GPU';
      try { landmarker = await HandLandmarker.createFromOptions(vision, options); }
      catch (gpuError) {
        console.warn('GPU delegate failed; switching to CPU.', gpuError);
        options.baseOptions = { modelAssetPath: MODEL_URL, delegate: 'CPU' };
        landmarker = await HandLandmarker.createFromOptions(vision, options); delegate = 'CPU';
      }
      self.postMessage({ type: 'READY', delegate });
    } catch (error) { self.postMessage({ type: 'FATAL', message: error?.message || String(error) }); }
    return;
  }
  if (message.type === 'OPTIONS') {
    if (!landmarker) return;
    try { await landmarker.setOptions(message.options || {}); self.postMessage({ type: 'OPTIONS_OK' }); }
    catch (error) { self.postMessage({ type: 'WARNING', message: error?.message || String(error) }); }
    return;
  }
  if (message.type === 'FRAME') {
    const bitmap = message.bitmap;
    if (!landmarker || busy || !bitmap) { bitmap?.close?.(); return; }
    busy = true;
    const startedAt = performance.now();
    try {
      const result = landmarker.detectForVideo(bitmap, message.timestampMs);
      const processingMs = performance.now() - startedAt;
      self.postMessage({
        type: 'RESULT', frameId: message.frameId, sessionId: message.sessionId,
        sentAt: message.sentAt, processingMs,
        landmarks: result.landmarks || [], worldLandmarks: result.worldLandmarks || [], handedness: result.handedness || [],
      });
    } catch (error) {
      self.postMessage({ type: 'INFERENCE_ERROR', frameId: message.frameId, sessionId: message.sessionId, message: error?.message || String(error) });
    } finally { bitmap.close?.(); busy = false; }
  }
};
self.addEventListener('close', () => { try { landmarker?.close(); } catch { /* worker teardown */ } });
