@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado. Instale Node.js 22.12 ou superior.
  echo https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules (
  echo Instalando dependencias do VRBox Neural Tracking...
  call npm install
  if errorlevel 1 (
    echo Falha ao instalar dependencias. Verifique sua internet e tente novamente.
    pause
    exit /b 1
  )
)
echo Iniciando servidor local...
call npm run dev
pause
