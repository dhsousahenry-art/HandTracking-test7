import test from 'node:test';
import assert from 'node:assert/strict';
import { BenchmarkRecorder } from '../src/benchmark.js';

test('benchmark exports expected CSV columns and summary', () => {
  const recorder = new BenchmarkRecorder();
  recorder.start();
  recorder.add({ fps: 30, inferenceMs: 12, pipelineMs: 18, hands: 1, confidence: 0.9, motionSpeed: 0.2, sharpness: 40, blurRisk: 0, predictedHands: 0 });
  recorder.add({ fps: 29, inferenceMs: 16, pipelineMs: 24, hands: 2, confidence: 0.8, motionSpeed: 0.4, sharpness: 20, blurRisk: 1, predictedHands: 1 });
  recorder.stop();
  assert.equal(recorder.summary().samples, 2);
  assert.match(recorder.toCSV(), /pipelineMs/);
  assert.match(recorder.toCSV(), /predictedHands/);
});
