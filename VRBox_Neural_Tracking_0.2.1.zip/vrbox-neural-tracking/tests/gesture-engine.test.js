import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyGesture } from '../src/gesture-engine.js';

test('gesture engine safely handles missing landmarks', () => {
  assert.equal(classifyGesture([]).key, 'none');
});

test('gesture engine reports a gesture for a plausible 21-point hand', () => {
  const points = Array.from({ length: 21 }, (_, i) => ({ x: 0.5 + (i % 4) * 0.015, y: 0.5 + Math.floor(i / 4) * 0.02, z: 0 }));
  const gesture = classifyGesture(points);
  assert.equal(typeof gesture.key, 'string');
  assert.equal(gesture.extended.length, 5);
});
