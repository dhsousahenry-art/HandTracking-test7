import test from 'node:test';
import assert from 'node:assert/strict';
import { TemporalPoseEngine } from '../src/temporal-engine.js';

const hand = (offset = 0) => Array.from({ length: 21 }, (_, index) => ({ x: 0.3 + index * 0.003 + offset, y: 0.4 + index * 0.002, z: 0 }));
const result = (landmarks) => ({ landmarks: [landmarks], worldLandmarks: [landmarks], handedness: [[{ categoryName: 'Left', score: 0.96 }]] });

test('temporal engine returns observed hand and bounded velocity', () => {
  const engine = new TemporalPoseEngine();
  const first = engine.update(result(hand()), 1000);
  const second = engine.update(result(hand(0.02)), 1033);
  assert.equal(first.hands.length, 1);
  assert.equal(second.hands[0].predicted, false);
  assert.ok(second.meanSpeed > 0);
});

test('temporal engine holds a briefly missing hand as predicted', () => {
  const engine = new TemporalPoseEngine({ holdMs: 160 });
  engine.update(result(hand()), 1000);
  const recovered = engine.update({ landmarks: [], worldLandmarks: [], handedness: [] }, 1080);
  assert.equal(recovered.predictedCount, 1);
  assert.equal(recovered.hands[0].predicted, true);
  const expired = engine.update({ landmarks: [], worldLandmarks: [], handedness: [] }, 1200);
  assert.equal(expired.hands.length, 0);
});

test('hold duration can be disabled', () => {
  const engine = new TemporalPoseEngine({ holdMs: 0 });
  engine.update(result(hand()), 1000);
  const noHold = engine.update({ landmarks: [], worldLandmarks: [], handedness: [] }, 1010);
  assert.equal(noHold.hands.length, 0);
});

test('temporal engine predicts world-space landmarks in world coordinates', () => {
  const engine = new TemporalPoseEngine({ holdMs: 160 });
  const first = hand(0);
  const second = hand(0.02);
  const firstWorld = first.map((point) => ({ x: point.x * 0.1, y: point.y * 0.1, z: point.z }));
  const secondWorld = firstWorld.map((point) => ({ ...point, x: point.x + 0.01 }));
  const wrap = (landmarks, worldLandmarks) => ({
    landmarks: [landmarks],
    worldLandmarks: [worldLandmarks],
    handedness: [[{ categoryName: 'Left', score: 0.96 }]],
  });
  engine.update(wrap(first, firstWorld), 1000);
  engine.update(wrap(second, secondWorld), 1033);
  const held = engine.update({ landmarks: [], worldLandmarks: [], handedness: [] }, 1083);
  assert.equal(held.hands[0].predicted, true);
  assert.ok(held.hands[0].worldLandmarks[0].x > secondWorld[0].x);
});
